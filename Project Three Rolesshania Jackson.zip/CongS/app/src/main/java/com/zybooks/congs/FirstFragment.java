package com.zybooks.congs;

import androidx.fragment.app.Fragment;

public class FirstFragment extends Fragment {
    public FirstFragment() {
        super(R.layout.fragment_first);
    }
}