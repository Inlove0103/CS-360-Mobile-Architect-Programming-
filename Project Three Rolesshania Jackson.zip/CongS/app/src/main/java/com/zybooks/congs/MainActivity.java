package com.example.congs;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

/**
 * MainActivity handles user interaction and SMS notification logic.
 * It requests runtime permission for SMS and sends alerts if granted.
 */
public class MainActivity extends AppCompatActivity {

    // Constant for permission request code
    private static final int REQUEST_SMS_PERMISSION = 101;

    // Sample phone number and message (replace with dynamic values in production)
    private static final String ALERT_PHONE_NUMBER = "1234567890";
    private static final String ALERT_MESSAGE = "Reminder: Your driving lesson is tomorrow at 10 AM.";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Check if SMS permission is already granted
        if (isSmsPermissionGranted()) {
            sendSmsAlert(); // Send alert immediately
        } else {
            requestSmsPermission(); // Ask user for permission
        }
    }

    /**
     * Checks whether the SEND_SMS permission has been granted.
     * @return true if permission is granted, false otherwise
     */
    private boolean isSmsPermissionGranted() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    /**
     * Requests SEND_SMS permission from the user.
     */
    private void requestSmsPermission() {
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.SEND_SMS},
                REQUEST_SMS_PERMISSION);
    }

    /**
     * Handles the result of the permission request.
     * If granted, sends the SMS alert. If denied, continues app functionality.
     */
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_SMS_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                sendSmsAlert(); // Permission granted
            } else {
                // Permission denied — notify user and continue without SMS
                Toast.makeText(this,
                        "SMS permission denied. Notifications will be disabled.",
                        Toast.LENGTH_LONG).show();
            }
        }
    }

    /**
     * Sends an SMS alert using the default SmsManager.
     * Assumes permission has already been granted.
     */
    private void sendSmsAlert() {
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(ALERT_PHONE_NUMBER, null, ALERT_MESSAGE, null, null);

        Toast.makeText(this, "SMS alert sent!", Toast.LENGTH_SHORT).show();
    }
}